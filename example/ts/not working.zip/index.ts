/*
Hi there!

We were unable to get this example working, and we would like to know if you could help us out.
If you manage to get it working, please let us know how you did it!
*/

import { CommandHandler, FunctionHandler, EventHandler } from 'discord-multi-handler'
import { Client, GatewayIntentBits, Collection } from 'discord.js'

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

const commandHandler = new CommandHandler(client);
commandHandler.fetchCommands({
    directory: `./commands`,
    singleFolder: true // true = single folder (All commands in one folder)
});

const eventHandler = new EventHandler(client);
eventHandler.fetchEvents({
    directory: `./events`,
    singleFolder: true // true = single folder (All events in one folder)
});

const functionHandler = new FunctionHandler(client);
functionHandler.fetchFunctions({
    directory: `./functions`,
    singleFolder: true // true = single folder (All functions in one folder)
});

client.login('');

export default interface PlainStuff extends Client {
    commands: Collection<string, any>;
    functions: (...args: any) => any;
    // all your other properties

}