import Client from "../"

export const execute = (client: Client, arg1: string, arg2: string) => {
    console.log(`Test function called! Args: ${arg1}, ${arg2}`)
}